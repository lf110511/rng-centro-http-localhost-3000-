# Checklist de publicação

## Antes do deploy
- [ ] Subir o conteúdo para um repositório GitHub privado ou público.
- [ ] Não enviar `.env` nem senhas reais.
- [ ] No Render, informar `OWNER_EMAIL`.
- [ ] No Render, informar `INITIAL_OWNER_PASSWORD` (8+ caracteres).
- [ ] Manter `SESSION_SECRET` gerado pelo Render.

## Depois do deploy
- [ ] Abrir a URL HTTPS do serviço.
- [ ] Entrar com o e-mail e senha do proprietário configurados no Render.
- [ ] Criar uma conta de teste.
- [ ] Verificar permissões de Proprietário, Líder, Treinador, Aluno e Membro.
- [ ] Testar a área de Link Profissional.

Nunca use `http://localhost:3000` como link para outras pessoas.
